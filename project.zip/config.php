<?php
// config.php
//dbCon 
define('DB_HOST', 'localhost');
define('DB_NAME', 'yellow');
define('DB_USER', 'computify');
define('DB_PASSWORD', 'com321test@123');

//payhere
define('MERCHANT_ID', '1225689');
define('MERCHANT_SECRET', 'Njc4OTAyNTQ0NDA1NzQ2OTA5MzE0MjIzNTU0NTAyNTgyMDg0Njk3');

//OTP
define('SMTP_USER', 'computify50@gmail.com');
define('SMTP_PASS', 'wraz axyl cdgr ergq');
define('MAIL_FROM_EMAIL', 'computify50@gmail.com');
define('MAIL_FROM_NAME', 'NoReply');
define('SMTP_HOST', 'smtp.gmail.com');


/*
CREATE USER 'computify'@'localhost' IDENTIFIED BY 'com321test@123';*/
