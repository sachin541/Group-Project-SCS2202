<?php include("header_layout.php"); ?>

<a href="../views_customer/product_list.php" class="topnav-item">Products</a>
<!-- <a href="../pages/product_list.php" class="topnav-item">Request Products</a> -->
<!-- <a href="../pages/repairs.php" class="topnav-item">Repairs</a> -->
<a href="../views_main/contact_us.php" class="topnav-item">Contact Us</a>
<a href="../views_main/login.php" class="unreg-log">Login</a>
<a href="../views_main/reg.php" class="unreg-log">Sign-up</a>

<?php include("header_layout_end.php"); ?>