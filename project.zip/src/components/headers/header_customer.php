<?php include("header_layout.php"); ?>

<a href="../views_customer/product_list.php" class="topnav-item">Products</a>
<a href="../views_customer/view_cart.php" class="topnav-item">Cart</a>
<a href="../views_customer/repairs.php" class="topnav-item">Repairs</a>
<a href="../views_customer/build_Item_selector.php" class="topnav-item">Builds</a>

<!-- <a href="../pages/product_list.php" class="topnav-item">Request Products</a> -->
<!-- <a href="../pages/repairs.php" class="topnav-item">Repairs</a> -->
<a href="../views_customer/OrderList.php" class="topnav-item">Orders</a>
<a href="../ultils/logout.php" class="unreg-log">Logout</a>

<?php include("header_layout_end.php");