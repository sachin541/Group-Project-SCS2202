<!DOCTYPE html>
<html>
<head>
    <title>Navigation Sidebar</title>
    
</head>
<body>

<nav class="nav-panel">
  <ul class="nav-list">
    <li class="nav-item">
      <!-- Replace with a link to the default page -->
      <a href="./reportsMain.php" class="nav-link">Default</a>
    </li>
    <li class="nav-item">
      <!-- Replace with a link to the echo page -->
      <a href="reportsBuilds.php" class="nav-link">Builds Data</a>
    </li>
    <li class="nav-item">
      <a href="./reportsItemSales.php" class="nav-link">Item Sales</a>
    </li>
  </ul>
</nav>



</body>
</html>
