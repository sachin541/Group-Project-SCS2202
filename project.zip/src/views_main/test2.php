<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Test Email</title>
</head>
<body>
    <!-- Main Content -->
    
    <form action="test.php" method="post">
        <button type="submit" name="send_test_email">Send Test Email</button>
    </form>
    
    <!-- Rest of your HTML content -->
</body>
</html>

